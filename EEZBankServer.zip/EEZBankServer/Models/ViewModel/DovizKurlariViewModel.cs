﻿namespace EEZBankServer.Models.ViewModel
{
    public class DovizKurlariViewModel
    {
        public string Code { get; set; }

        public decimal BuyRate { get; set; }

        public decimal SellRate { get; set; }

        public DateTime UpdateTime { get; set; }
    }
}
